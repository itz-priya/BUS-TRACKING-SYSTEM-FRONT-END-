
  # Offline Bus Tracking System

  This is a code bundle for Offline Bus Tracking System. The original project is available at https://www.figma.com/design/t2pmcWjYGPWoHL0ZvIs5oX/Offline-Bus-Tracking-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  