import { useState } from "react";
import { Bus, Clock, MapPin, Phone, MessageSquare, Wifi, WifiOff } from "lucide-react";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

interface BusArrival {
  busNumber: string;
  destination: string;
  arrivalTime: number;
  status: "on-time" | "delayed" | "arriving";
}

export function BusTracker() {
  const [busNumber, setBusNumber] = useState("");
  const [stopNumber, setStopNumber] = useState("");
  const [isOffline, setIsOffline] = useState(false);

  // Mock data for demonstration
  const mockArrivals: BusArrival[] = [
    { busNumber: "42", destination: "Downtown", arrivalTime: 3, status: "arriving" },
    { busNumber: "17", destination: "Airport", arrivalTime: 8, status: "on-time" },
    { busNumber: "28", destination: "University", arrivalTime: 15, status: "delayed" },
    { busNumber: "9", destination: "Mall", arrivalTime: 22, status: "on-time" },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "arriving":
        return "text-[#ff0080]";
      case "on-time":
        return "text-green-400";
      case "delayed":
        return "text-yellow-400";
      default:
        return "text-gray-400";
    }
  };

  return (
    <div className="min-h-screen bg-black text-white" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <header className="border-b border-[#ff0080]/20 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Bus className="w-8 h-8 text-[#ff0080]" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#ff0080] rounded-full animate-pulse"></div>
            </div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              BusTrack<span className="text-[#ff0080]">.</span>
            </h1>
          </div>
          <button
            onClick={() => setIsOffline(!isOffline)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#1a1a1a] border border-[#ff0080]/20 hover:border-[#ff0080]/50 transition-all"
          >
            {isOffline ? (
              <>
                <WifiOff className="w-4 h-4 text-[#ff0080]" />
                <span className="text-sm">Offline Mode</span>
              </>
            ) : (
              <>
                <Wifi className="w-4 h-4 text-green-400" />
                <span className="text-sm">Online</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-5xl font-bold mb-4 neon-text" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Track Your Bus
            <br />
            <span className="text-[#ff0080]">Anytime, Anywhere</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Real-time bus arrival information via SMS, missed call, or web app.
            <br />
            No internet? No problem.
          </p>
        </div>

        {/* Search Section */}
        <Card className="max-w-3xl mx-auto p-6 bg-[#0a0a0a] border-[#ff0080]/20 neon-glow">
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Bus Number</label>
              <Input
                type="text"
                placeholder="e.g., 42"
                value={busNumber}
                onChange={(e) => setBusNumber(e.target.value)}
                className="bg-black border-[#ff0080]/30 focus:border-[#ff0080] text-white"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Stop Number</label>
              <Input
                type="text"
                placeholder="e.g., 12345"
                value={stopNumber}
                onChange={(e) => setStopNumber(e.target.value)}
                className="bg-black border-[#ff0080]/30 focus:border-[#ff0080] text-white"
              />
            </div>
          </div>
          <Button className="w-full bg-[#ff0080] hover:bg-[#cc0066] text-white shadow-lg shadow-[#ff0080]/50">
            <MapPin className="w-4 h-4 mr-2" />
            Track Bus
          </Button>
        </Card>
      </section>

      {/* Live Arrivals */}
      <section className="container mx-auto px-4 py-12">
        <h3 className="text-3xl font-bold mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Live Arrivals
        </h3>
        <div className="grid gap-4">
          {mockArrivals.map((arrival, index) => (
            <Card
              key={index}
              className="p-5 bg-[#0a0a0a] border-[#ff0080]/20 hover:border-[#ff0080]/50 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-[#1a1a1a] border border-[#ff0080]/30 flex items-center justify-center group-hover:border-[#ff0080] transition-all">
                    <span className="text-2xl font-bold text-[#ff0080]" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                      {arrival.busNumber}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-1">{arrival.destination}</h4>
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <MapPin className="w-4 h-4" />
                      <span>Stop #12345</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center justify-end gap-2 mb-2">
                    <Clock className="w-5 h-5 text-[#ff0080]" />
                    <span className="text-3xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                      {arrival.arrivalTime}
                    </span>
                    <span className="text-gray-400">min</span>
                  </div>
                  <span className={`text-sm ${getStatusColor(arrival.status)}`}>
                    {arrival.status === "arriving" && "Arriving Soon"}
                    {arrival.status === "on-time" && "On Time"}
                    {arrival.status === "delayed" && "Delayed"}
                  </span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Offline Access Methods */}
      <section className="container mx-auto px-4 py-12">
        <h3 className="text-3xl font-bold mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Access Without Internet
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-6 bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] border-[#ff0080]/20 hover:border-[#ff0080]/50 transition-all">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-[#ff0080]/10 border border-[#ff0080]/30 flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-[#ff0080]" />
              </div>
              <div>
                <h4 className="text-xl font-semibold mb-2">SMS Service</h4>
                <p className="text-gray-400 mb-4">
                  Text "BUS [number] [stop]" to{" "}
                  <span className="text-[#ff0080] font-mono">55555</span>
                </p>
                <div className="bg-black/50 p-3 rounded-lg border border-[#ff0080]/20">
                  <code className="text-sm text-[#ff0080]">SMS: BUS 42 12345</code>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] border-[#ff0080]/20 hover:border-[#ff0080]/50 transition-all">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-[#ff0080]/10 border border-[#ff0080]/30 flex items-center justify-center">
                <Phone className="w-6 h-6 text-[#ff0080]" />
              </div>
              <div>
                <h4 className="text-xl font-semibold mb-2">Missed Call</h4>
                <p className="text-gray-400 mb-4">
                  Give a missed call to{" "}
                  <span className="text-[#ff0080] font-mono">1800-BUS-INFO</span>
                </p>
                <div className="bg-black/50 p-3 rounded-lg border border-[#ff0080]/20">
                  <code className="text-sm text-[#ff0080]">Call: 1800-287-4636</code>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-12">
        <h3 className="text-3xl font-bold mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Key Features
        </h3>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              title: "Offline First",
              description: "Works without internet via SMS and missed calls",
              icon: WifiOff,
            },
            {
              title: "Real-time GPS",
              description: "Live bus location and accurate arrival times",
              icon: MapPin,
            },
            {
              title: "Feature Phone Support",
              description: "Accessible on any phone, smart or basic",
              icon: Phone,
            },
          ].map((feature, index) => (
            <Card
              key={index}
              className="p-6 bg-[#0a0a0a] border-[#ff0080]/20 hover:border-[#ff0080]/50 transition-all text-center"
            >
              <div className="w-16 h-16 rounded-full bg-[#ff0080]/10 border border-[#ff0080]/30 flex items-center justify-center mx-auto mb-4">
                <feature.icon className="w-8 h-8 text-[#ff0080]" />
              </div>
              <h4 className="text-xl font-semibold mb-2">{feature.title}</h4>
              <p className="text-gray-400">{feature.description}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#ff0080]/20 mt-12">
        <div className="container mx-auto px-4 py-8 text-center text-gray-400">
          <p>© 2024 BusTrack. Real-time bus tracking for everyone.</p>
        </div>
      </footer>
    </div>
  );
}