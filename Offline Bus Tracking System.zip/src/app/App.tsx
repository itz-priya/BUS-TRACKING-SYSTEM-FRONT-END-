import { BusTracker } from "./components/BusTracker";

export default function App() {
  return <BusTracker />;
}
